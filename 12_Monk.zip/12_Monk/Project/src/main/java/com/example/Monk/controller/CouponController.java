package com.example.couponservice.controller;

import com.example.couponservice.model.Coupon;
import com.example.couponservice.model.Product;
import com.example.couponservice.service.CouponService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class CouponController {

    @Autowired
    private CouponService couponService;

    // ----------------- Coupon CRUD -----------------

    @PostMapping("/coupons")
    public Coupon createCoupon(@RequestBody Coupon coupon) {
        return couponService.createCoupon(coupon);
    }

    @GetMapping("/coupons")
    public List<Coupon> getAllCoupons() {
        return couponService.getAllCoupons();
    }

    @GetMapping("/coupons/{id}")
    public Coupon getCouponById(@PathVariable Integer id) {
        return couponService.getCouponById(id);
    }

    @PutMapping("/coupons/{id}")
    public Coupon updateCoupon(@PathVariable Integer id, @RequestBody Coupon coupon) {
        return couponService.updateCoupon(id, coupon);
    }

    @DeleteMapping("/coupons/{id}")
    public String deleteCoupon(@PathVariable Integer id) {
        couponService.deleteCoupon(id);
        return "Coupon deleted successfully";
    }

    // ----------------- Apply Coupon -----------------

    @PostMapping("/apply-coupon/{couponCode}")
    public Map<Integer, Integer> applyCoupon(@PathVariable String couponCode,
                                             @RequestParam Integer userId,
                                             @RequestBody List<Product> cart) {
        return couponService.applyCoupon(cart, couponCode, userId);
    }

    // ----------------- Applicable Coupons -----------------
    // For simplicity, just returning all coupons applicable to a given cart
    @PostMapping("/applicable-coupons")
    public Map<String, Map<Integer, Integer>> getApplicableCoupons(@RequestParam Integer userId,
                                                                   @RequestBody List<Product> cart) {
        Map<String, Map<Integer, Integer>> result = new java.util.HashMap<>();
        List<Coupon> allCoupons = couponService.getAllCoupons();
        for (Coupon c : allCoupons) {
            try {
                Map<Integer, Integer> discounted = couponService.applyCoupon(cart, c.getCouponCode(), userId);
                result.put(c.getCouponCode(), discounted);
            } catch (Exception e) {
                // skip coupons not applicable
            }
        }
        return result;
    }
}