package com.example.Monk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonkApplicationTests {

	@Test
	void contextLoads() {
	}

}
