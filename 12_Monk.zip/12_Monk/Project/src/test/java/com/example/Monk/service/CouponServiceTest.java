package com.example.couponservice.service;

import com.example.couponservice.model.Coupon;
import com.example.couponservice.model.CouponUsage;
import com.example.couponservice.model.Product;
import com.example.couponservice.repository.CouponRepository;
import com.example.couponservice.repository.CouponUsageRepository;
import com.example.couponservice.strategy.CouponStrategy;
import com.example.couponservice.strategy.CouponStrategyFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CouponServiceTest {

    @Mock
    private CouponRepository couponRepository;

    @Mock
    private CouponUsageRepository couponUsageRepository;

    @Mock
    private CouponStrategyFactory strategyFactory;

    @Mock
    private CouponStrategy mockStrategy;

    @InjectMocks
    private CouponService couponService;

    private Coupon coupon;
    private Product product;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        coupon = new Coupon();
        coupon.setId(1);
        coupon.setCouponCode("DISC10");
        coupon.setType("cart-wise");
        coupon.setIsActive(true);
        coupon.setStartDate(LocalDate.now().minusDays(1));
        coupon.setEndDate(LocalDate.now().plusDays(1));
        coupon.setMaxUsesPerUser(5);

        product = new Product();
        product.setId(101);
        product.setPrice(500);
    }

    @Test
    void testApplyCoupon_success() {

        List<Product> cart = List.of(product);

        // Mock repo returns coupon
        when(couponRepository.findByCouponCode("DISC10"))
                .thenReturn(Optional.of(coupon));

        // No previous usage
        when(couponUsageRepository.findByUserIdAndCouponId(99, 1))
                .thenReturn(Optional.empty());

        // Strategy selected
        when(strategyFactory.getStrategy("cart-wise"))
                .thenReturn(mockStrategy);

        // Strategy returns discount result
        Map<Integer, Integer> discountResult = Map.of(101, 450);
        when(mockStrategy.applyCoupon(cart, coupon)).thenReturn(discountResult);

        Map<Integer, Integer> response =
                couponService.applyCoupon(cart, "DISC10", 99);

        assertEquals(450, response.get(101));
        verify(couponUsageRepository, times(1)).save(any());
    }

    @Test
    void testApplyCoupon_notFound() {
        when(couponRepository.findByCouponCode("INVALID"))
                .thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> couponService.applyCoupon(List.of(product), "INVALID", 1));
    }

    @Test
    void testApplyCoupon_expired() {
        coupon.setEndDate(LocalDate.now().minusDays(1));

        when(couponRepository.findByCouponCode("DISC10"))
                .thenReturn(Optional.of(coupon));

        assertThrows(IllegalArgumentException.class,
                () -> couponService.applyCoupon(List.of(product), "DISC10", 1));
    }

    @Test
    void testApplyCoupon_maxUsageExceeded() {

        CouponUsage usage = new CouponUsage();
        usage.setUsedCount(5); // Already at max

        when(couponRepository.findByCouponCode("DISC10"))
                .thenReturn(Optional.of(coupon));

        when(couponUsageRepository.findByUserIdAndCouponId(1, 1))
                .thenReturn(Optional.of(usage));

        assertThrows(IllegalArgumentException.class,
                () -> couponService.applyCoupon(List.of(product), "DISC10", 1));
    }

    @Test
    void testGetAllCoupons() {
        when(couponRepository.findAll()).thenReturn(List.of(coupon));

        List<Coupon> list = couponService.getAllCoupons();

        assertEquals(1, list.size());
    }

    @Test
    void testDeleteCoupon() {
        when(couponRepository.findById(1)).thenReturn(Optional.of(coupon));

        couponService.deleteCoupon(1);

        verify(couponRepository, times(1)).delete(coupon);
    }
}