package com.example.couponservice.repository;

import com.example.couponservice.model.CouponUsage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CouponUsageRepository extends JpaRepository<CouponUsage, Integer> {
    Optional<CouponUsage> findByUserIdAndCouponId(Integer userId, Integer couponId);
}