package com.example.couponservice.strategy;

import com.example.couponservice.model.Coupon;
import com.example.couponservice.model.Product;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class BxGyCouponStrategy implements CouponStrategy {

    @Override
    public Map<Integer, Integer> applyCoupon(List<Product> cart, Coupon coupon) {
        Map<Integer, Integer> discountedMap = new HashMap<>();

        // Example metadata: buy:1|2|3,get:4|5,repeat:2
        String[] parts = coupon.getMetadata().split(",");
        String[] buyIds = parts[0].split(":")[1].split("\\|");
        String[] getIds = parts[1].split(":")[1].split("\\|");
        int repeatLimit = Integer.parseInt(parts[2].split(":")[1]);

        int buyCount = 0;
        int getCount = 0;

        for (Product p : cart) {
            for (String bid : buyIds) {
                if (p.getId() == Integer.parseInt(bid)) buyCount += p.getQuantity();
            }
            for (String gid : getIds) {
                if (p.getId() == Integer.parseInt(gid)) getCount += p.getQuantity();
            }
        }

        int applicableTimes = Math.min(buyCount / repeatLimit, getCount);
        for (Product p : cart) {
            int price = p.getPrice();
            boolean free = false;
            for (String gid : getIds) {
                if (p.getId() == Integer.parseInt(gid) && applicableTimes > 0) {
                    price = 0; // free product
                    applicableTimes--;
                    free = true;
                    break;
                }
            }
            discountedMap.put(p.getId(), price);
        }

        return discountedMap;
    }
}