package com.example.couponservice.strategy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CouponStrategyFactory {

    @Autowired
    private CartWiseCouponStrategy cartWiseStrategy;

    @Autowired
    private ProductWiseCouponStrategy productWiseStrategy;

    @Autowired
    private BxGyCouponStrategy bxGyStrategy;

    public CouponStrategy getStrategy(String type) {
        return switch (type.toLowerCase()) {
            case "cart-wise" -> cartWiseStrategy;
            case "product-wise" -> productWiseStrategy;
            case "bxgy" -> bxGyStrategy;
            default -> throw new IllegalArgumentException("Unknown coupon type: " + type);
        };
    }
}