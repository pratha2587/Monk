package com.example.couponservice.strategy;

import com.example.couponservice.model.Coupon;
import com.example.couponservice.model.Product;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ProductWiseCouponStrategy implements CouponStrategy {

    @Override
    public Map<Integer, Integer> applyCoupon(List<Product> cart, Coupon coupon) {
        Map<Integer, Integer> discountedMap = new HashMap<>();

        // metadata example: "productIds:1|2|3,discount:20"
        String[] parts = coupon.getMetadata().split(",");
        String[] productIds = parts[0].split(":")[1].split("\\|");
        int discountPercent = Integer.parseInt(parts[1].split(":")[1]);

        for (Product p : cart) {
            boolean applicable = false;
            for (String pid : productIds) {
                if (Integer.parseInt(pid) == p.getId()) {
                    applicable = true;
                    break;
                }
            }
            int discountedPrice = applicable ? p.getPrice() - (p.getPrice() * discountPercent / 100) : p.getPrice();
            discountedMap.put(p.getId(), discountedPrice);
        }

        return discountedMap;
    }
}