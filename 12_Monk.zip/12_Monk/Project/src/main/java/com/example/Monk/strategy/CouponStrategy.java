package com.example.couponservice.strategy;

import com.example.couponservice.model.Coupon;
import com.example.couponservice.model.Product;

import java.util.List;
import java.util.Map;

public interface CouponStrategy {

    /**
     * Apply coupon to the given cart (list of products) and return a map of product ID to discounted price
     * @param cart list of products in the cart
     * @param coupon coupon to apply
     * @return map of productId -> discounted price
     */
    Map<Integer, Integer> applyCoupon(List<Product> cart, Coupon coupon);
}