package com.example.couponservice.strategy;

import com.example.couponservice.model.Coupon;
import com.example.couponservice.model.Product;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class CartWiseCouponStrategy implements CouponStrategy {

    @Override
    public Map<Integer, Integer> applyCoupon(List<Product> cart, Coupon coupon) {
        Map<Integer, Integer> discountedMap = new HashMap<>();
        int cartTotal = cart.stream().mapToInt(p -> p.getPrice() * p.getQuantity()).sum();

        // Assuming metadata contains minimum cart value and discount percentage as "minCart:100,discount:10"
        String[] parts = coupon.getMetadata().split(",");
        int minCartValue = Integer.parseInt(parts[0].split(":")[1]);
        int discountPercent = Integer.parseInt(parts[1].split(":")[1]);

        if (cartTotal >= minCartValue) {
            for (Product p : cart) {
                int discountedPrice = p.getPrice() - (p.getPrice() * discountPercent / 100);
                discountedMap.put(p.getId(), discountedPrice);
            }
        } else {
            for (Product p : cart) {
                discountedMap.put(p.getId(), p.getPrice());
            }
        }
        return discountedMap;
    }
}