package com.example.couponservice.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "coupon_details")
public class Coupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String type; // cart-wise, product-wise, BxGy

    private String metadata; // JSON or string for discount details

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "coupon_code", unique = true)
    private String couponCode;

    @Column(name = "number_of_users_allowed")
    private Integer numberOfUsersAllowed;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "max_discount")
    private Integer maxDiscount;

    @Column(name = "max_user")
    private Integer maxUser;

    @Column(name = "max_uses_per_user")
    private Integer maxUsesPerUser;

    @Column(name = "total_available_count")
    private Integer totalAvailableCount;

    // Getters and setters

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getMetadata() { return metadata; }
    public void setMetadata(String metadata) { this.metadata = metadata; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public String getCouponCode() { return couponCode; }
    public void setCouponCode(String couponCode) { this.couponCode = couponCode; }

    public Integer getNumberOfUsersAllowed() { return numberOfUsersAllowed; }
    public void setNumberOfUsersAllowed(Integer numberOfUsersAllowed) { this.numberOfUsersAllowed = numberOfUsersAllowed; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    public Integer getMaxDiscount() { return maxDiscount; }
    public void setMaxDiscount(Integer maxDiscount) { this.maxDiscount = maxDiscount; }

    public Integer getMaxUser() { return maxUser; }
    public void setMaxUser(Integer maxUser) { this.maxUser = maxUser; }

    public Integer getMaxUsesPerUser() { return maxUsesPerUser; }
    public void setMaxUsesPerUser(Integer maxUsesPerUser) { this.maxUsesPerUser = maxUsesPerUser; }

    public Integer getTotalAvailableCount() { return totalAvailableCount; }
    public void setTotalAvailableCount(Integer totalAvailableCount) { this.totalAvailableCount = totalAvailableCount; }
}