package com.example.couponservice.service;

import com.example.couponservice.model.Coupon;
import com.example.couponservice.model.CouponUsage;
import com.example.couponservice.model.Product;
import com.example.couponservice.repository.CouponRepository;
import com.example.couponservice.repository.CouponUsageRepository;
import com.example.couponservice.strategy.CouponStrategy;
import com.example.couponservice.strategy.CouponStrategyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class CouponService {

    @Autowired
    private CouponRepository couponRepository;

    @Autowired
    private CouponUsageRepository couponUsageRepository;

    @Autowired
    private CouponStrategyFactory strategyFactory;

    /**
     * Apply a coupon to the cart
     * @param cart list of products
     * @param couponCode coupon code string
     * @param userId user applying the coupon
     * @return map of productId -> discounted price
     */
    public Map<Integer, Integer> applyCoupon(List<Product> cart, String couponCode, Integer userId) {
        Optional<Coupon> optionalCoupon = couponRepository.findByCouponCode(couponCode);
        if (optionalCoupon.isEmpty()) {
            throw new IllegalArgumentException("Coupon not found");
        }

        Coupon coupon = optionalCoupon.get();

        // Check validity dates
        LocalDate today = LocalDate.now();
        if (!coupon.getIsActive() || coupon.getStartDate().isAfter(today) || coupon.getEndDate().isBefore(today)) {
            throw new IllegalArgumentException("Coupon is not valid today");
        }

        // Check usage limits
        CouponUsage usage = couponUsageRepository.findByUserIdAndCouponId(userId, coupon.getId())
                .orElse(null);

        if (usage != null && usage.getUsedCount() >= coupon.getMaxUsesPerUser()) {
            throw new IllegalArgumentException("User has exceeded coupon usage limit");
        }

        // Strategy pattern: select strategy based on type
        CouponStrategy strategy = strategyFactory.getStrategy(coupon.getType());

        Map<Integer, Integer> discountedMap = strategy.applyCoupon(cart, coupon);

        // Update usage count
        if (usage == null) {
            usage = new CouponUsage();
            usage.setUserId(userId);
            usage.setCoupon(coupon);
            usage.setUsedCount(1);
        } else {
            usage.setUsedCount(usage.getUsedCount() + 1);
        }
        couponUsageRepository.save(usage);

        return discountedMap;
    }

    /**
     * Fetch all coupons
     */
    public List<Coupon> getAllCoupons() {
        return couponRepository.findAll();
    }

    /**
     * Fetch coupon by ID
     */
    public Coupon getCouponById(Integer id) {
        return couponRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Coupon not found"));
    }

    /**
     * Create new coupon
     */
    public Coupon createCoupon(Coupon coupon) {
        return couponRepository.save(coupon);
    }

    /**
     * Update coupon by ID
     */
    public Coupon updateCoupon(Integer id, Coupon updatedCoupon) {
        Coupon existing = getCouponById(id);

        existing.setType(updatedCoupon.getType());
        existing.setMetadata(updatedCoupon.getMetadata());
        existing.setStartDate(updatedCoupon.getStartDate());
        existing.setEndDate(updatedCoupon.getEndDate());
        existing.setCouponCode(updatedCoupon.getCouponCode());
        existing.setIsActive(updatedCoupon.getIsActive());
        existing.setMaxDiscount(updatedCoupon.getMaxDiscount());
        existing.setMaxUser(updatedCoupon.getMaxUser());
        existing.setMaxUsesPerUser(updatedCoupon.getMaxUsesPerUser());
        existing.setTotalAvailableCount(updatedCoupon.getTotalAvailableCount());
        existing.setNumberOfUsersAllowed(updatedCoupon.getNumberOfUsersAllowed());

        return couponRepository.save(existing);
    }

    /**
     * Delete coupon by ID
     */
    public void deleteCoupon(Integer id) {
        Coupon existing = getCouponById(id);
        couponRepository.delete(existing);
    }
}